package net.justrotem.data;

import net.justrotem.data.data.PlayerData;
import net.justrotem.data.hooks.LuckPermsManager;
import net.justrotem.data.sql.MySQL;
import net.justrotem.data.sql.PlayerDataManager;
import net.justrotem.data.utils.TextUtility;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.*;
import java.util.concurrent.CancellationException;

public class PlayerManager {

    //<editor-fold desc="Data methods">
    private static final HashMap<UUID, PlayerData> CACHE = new HashMap<>();
    private static final PlayerDataManager sql = MySQL.getPlayerData();

    public static void register(Player player) {
        PlayerData playerData = get(player.getUniqueId());
        if (playerData == null) playerData = PlayerData.create(player);
        playerData.checkForUpdates(player);

        update(playerData);
    }

    private static void update(PlayerData playerData) {
        if (CACHE.containsKey(playerData.getUniqueId())) CACHE.get(playerData.getUniqueId()).clone(playerData);

        CACHE.put(playerData.getUniqueId(), playerData);
    }

    public static PlayerData get(UUID uuid) {
        if (uuid == null) return null;

        if (CACHE.containsKey(uuid)) return CACHE.get(uuid);

        try {
            return sql.getData(uuid).join();
        } catch (CancellationException e) {
            return null;
        }
    }

    public static List<PlayerData> getAll() {
        return sql.getAll().join();
    }

    public static void save(PlayerData playerData) {
        sql.update(playerData);
    }

    public static void saveAll() {
        CACHE.values().forEach(sql::update);
    }

    public static boolean isRegistered(UUID uuid) {
        if (uuid == null) return false;

        if (CACHE.containsKey(uuid)) return true;

        try {
            return sql.getData(uuid).join() != null;
        } catch (CancellationException e) {
            return false;
        }
    }
    //</editor-fold>

    //<editor-fold desc="Bukkit methods">
    private static final HashMap<Player, Component> lastMessages = new HashMap<>();

    public static boolean isRegisteredOffline(String name) {
        return Arrays.stream(Bukkit.getOfflinePlayers())
                .anyMatch(p -> p.getName() != null && p.getName().equalsIgnoreCase(name));
    }

    public static boolean isRegistered(String name) {
        return isRegistered(getUniqueId(name));
    }

    public static UUID getUniqueId(String name) {
        try {
            try {
                return Objects.requireNonNull(Arrays.stream(Bukkit.getOfflinePlayers()).filter(p -> p.getName() != null && p.getName().equalsIgnoreCase(name)).findFirst().orElse(null)).getUniqueId();
            } catch (NoSuchElementException | NullPointerException e) {
                return Objects.requireNonNull(CACHE.values().stream().filter(playerData -> playerData.getName().equalsIgnoreCase(name)).findFirst().orElse(null)).getUniqueId();
            }
        } catch (NullPointerException e) {
            return null;
        }
    }

    public static String getName(UUID uuid) {
        try {
            return Objects.requireNonNull(get(uuid)).getName();
        } catch (NullPointerException e) {
            return null;
        }
    }

    public static String getName(String name) {
        try {
            return Objects.requireNonNull(getName(getUniqueId(name)));
        } catch (NullPointerException e) {
            return null;
        }
    }

    public static Component getRealDisplayName(UUID uuid) {
        try {
            return LuckPermsManager.getGroupPrefix(LuckPermsManager.getPrimaryGroup(uuid)).append(Component.text(Objects.requireNonNull(getName(uuid))));
        } catch (Exception e) {
            return null;
        }
    }

    public static Component getRealDisplayName(Player player) {
        return LuckPermsManager.getGroupPrefix(LuckPermsManager.getPrimaryGroup(player)).append(player.name());
    }

    public static Component getDisplayName(Player player) {
        return LuckPermsManager.getPrefix(player.getUniqueId()).append(player.displayName());
    }

    public static String getLegacyRealDisplayName(UUID uuid) {
        return LuckPermsManager.getLegacyGroupPrefix(LuckPermsManager.getPrimaryGroup(uuid)) + getName(uuid);
    }

    public static String getLegacyRealDisplayName(Player player) {
        return LuckPermsManager.getLegacyGroupPrefix(LuckPermsManager.getPrimaryGroup(player)) + player.getName();
    }

    public static String getLegacyDisplayName(Player player) {
        return LuckPermsManager.getLegacyPrefix(player.getUniqueId()) + TextUtility.getText(player.displayName());
    }

    public static boolean isChatToggled(@NotNull Player player) {
        try {
            return Objects.requireNonNull(get(player.getUniqueId())).isToggleChat();
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean isSameMessage(@NotNull Player player, Component message) {
        if (player.hasPermission("batzal.chat.samemessage")) return false;

        if (!lastMessages.containsKey(player)) {
            setLastMessage(player, message);
            return false;
        }

        return TextUtility.getText(message).equals(TextUtility.getText(lastMessages.get(player)));
    }

    public static void setLastMessage(Player player, Component message) {
        lastMessages.put(player, message);
    }

    public static boolean isAdvertising(@NotNull Player player, Component message) {
        if (player.hasPermission("batzal.chat.advertisement")) return false;

        String text = TextUtility.getText(message).toLowerCase();
        return text.contains("http") || text.contains("www.");
    }
    //</editor-fold>
}
