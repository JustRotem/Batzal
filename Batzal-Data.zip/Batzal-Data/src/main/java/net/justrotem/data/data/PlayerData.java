package net.justrotem.data.data;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.NoSuchElementException;
import java.util.UUID;

public class PlayerData {

    public static PlayerData create(Player player) {
        return new PlayerData(player);
    }

    public static PlayerData create(UUID uuid, String name, String value, String signature, boolean vanished, boolean toggleChat, boolean togglePunch, int totalExperience, RankColor.Color rankColor, RankColor.PrefixColor prefixColor, PunchMessage punchMessage, MessageMode messageMode, Status status, Visibility.State visibilityState) {
        return new PlayerData(uuid, name, value, signature, vanished, toggleChat, togglePunch, totalExperience, rankColor, prefixColor, punchMessage, messageMode, status, visibilityState);
    }

    private final UUID uuid;
    private String name, value, signature;
    private boolean vanished, toggleChat, togglePunch;
    private int totalExperience;
    private RankColor.Color rankColor;
    private RankColor.PrefixColor prefixColor;
    private PunchMessage punchMessage;
    private MessageMode messageMode;
    private Status status;
    private Visibility.State visibilityState;

    protected PlayerData(Player player) {
        this.uuid = player.getUniqueId();

        String value;
        String signature;
        try {
            ProfileProperty property = player.getPlayerProfile().getProperties().iterator().next();
            value = property.getValue();
            signature = property.getSignature();
        } catch (NoSuchElementException e) {
            value = "";
            signature = "";
        }

        init(player.getName(), value, signature, false, false, false, 7, RankColor.Color.Red, RankColor.PrefixColor.Gold, PunchMessage.NONE, MessageMode.ANYONE, Status.Online, Visibility.State.VISIBLE);
    }

    protected PlayerData(UUID uuid, String name, String value, String signature, boolean vanished, boolean toggleChat, boolean togglePunch, int totalExperience, RankColor.Color rankColor, RankColor.PrefixColor prefixColor, PunchMessage punchMessage, MessageMode messageMode, Status status, Visibility.State visibilityState) {
        this.uuid = uuid;
        init(name, value, signature, vanished, toggleChat, togglePunch, totalExperience, rankColor, prefixColor, punchMessage, messageMode, status, visibilityState);
    }

    private void init(String name, String value, String signature, boolean vanished, boolean toggleChat, boolean togglePunch, int totalExperience, RankColor.Color rankColor, RankColor.PrefixColor prefixColor, PunchMessage punchMessage, MessageMode messageMode, Status status, Visibility.State visibilityState) {
        this.name = name;
        this.signature = signature;
        this.value = value;
        this.vanished = vanished;
        this.toggleChat = toggleChat;
        this.togglePunch = togglePunch;
        this.totalExperience = totalExperience;
        this.rankColor = rankColor;
        this.prefixColor = prefixColor;
        this.punchMessage = punchMessage;
        this.messageMode = messageMode;
        this.status = status;
        this.visibilityState = visibilityState;
    }

    public UUID getUniqueId() {
        return this.uuid;
    }

    public String getName() {
        return this.name;
    }

    public String getValue() {
        return this.value;
    }

    public String getSignature() {
        return this.signature;
    }

    public boolean isVanished() {
        return this.vanished;
    }

    public boolean isToggleChat() {
        return this.toggleChat;
    }

    public boolean isTogglePunch() {
        return this.togglePunch;
    }

    public int getTotalExperience() {
        return this.totalExperience;
    }

    public RankColor.Color getRankColor() {
        return this.rankColor;
    }

    public RankColor.PrefixColor getPrefixColor() {
        return this.prefixColor;
    }

    public PunchMessage getPunchMessage() {
        return this.punchMessage;
    }

    public MessageMode getMessageMode() {
        return this.messageMode;
    }

    public Status getStatus() {
        return this.status;
    }

    public Visibility.State getVisibilityState() {
        return this.visibilityState;
    }

    public void setVanished(boolean vanished) {
        this.vanished = vanished;
    }

    public void setToggleChat(boolean toggleChat) {
        this.toggleChat = toggleChat;
    }

    public void setTogglePunch(boolean togglePunch) {
        this.togglePunch = togglePunch;
    }

    public void setTotalExperience(int totalExperience) {
        this.totalExperience = totalExperience;
    }

    public void setRankColor(RankColor.Color rankColor) {
        this.rankColor = rankColor;
    }

    public void setPrefixColor(RankColor.PrefixColor prefixColor) {
        this.prefixColor = prefixColor;
    }

    public void setPunchMessage(PunchMessage punchMessage) {
        this.punchMessage = punchMessage;
    }

    public void setMessageMode(MessageMode messageMode) {
        this.messageMode = messageMode;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public void setVisibilityState(Visibility.State visibilityState) {
        this.visibilityState = visibilityState;
    }

    public void checkForUpdates(Player player) {
        if (!this.name.equals(player.getName())) this.name = player.getName();

        ProfileProperty property = player.getPlayerProfile().getProperties().iterator().next();
        if (!property.getValue().equals(this.value)) this.value = property.getValue();
        if (!property.getSignature().equals(this.signature)) this.signature = property.getSignature();
    }

    public void clone(PlayerData playerData) {
        init(playerData.name, playerData.value, playerData.value, playerData.vanished, playerData.toggleChat, playerData.togglePunch, playerData.totalExperience, playerData.rankColor, playerData.prefixColor, playerData.punchMessage, playerData.messageMode, playerData.status, playerData.visibilityState);
    }
}
