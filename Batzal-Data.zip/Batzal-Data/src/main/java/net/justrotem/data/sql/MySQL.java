package net.justrotem.data.sql;

import net.justrotem.data.utils.Utility;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public class MySQL {

    private static MySQLManager mySQL;
    private static PlayerDataManager userData;
    private static SkinDataManager skinData;

    public static void connect(JavaPlugin plugin) {
        // Save default mysql.yml if it doesn’t exist
        Utility.saveResource(plugin, "mysql.yml", false); // false = don’t overwrite existing file

        // Load mysql.yml
        File file = new File(plugin.getDataFolder(), "mysql.yml");
        FileConfiguration config = YamlConfiguration.loadConfiguration(file);

        mySQL = new MySQLManager(plugin,
                config.getString("MySQL.address"),
                3306,
                config.getString("MySQL.database"),
                config.getString("MySQL.username"),
                config.getString("MySQL.password")
        );

        mySQL.connect();

        userData = new PlayerDataManager(mySQL);
        skinData = new SkinDataManager(mySQL);
    }

    public static void disconnect() {
        mySQL.disconnect();
    }

    public static MySQLManager getMySQL() {
        return mySQL;
    }

    public static PlayerDataManager getPlayerData() {
        return userData;
    }

    public static SkinDataManager getSkinData() {
        return skinData;
    }
}
